## jQuery

If jQuery is detected on the page, then this library provides a simple jQuery interface. 

```js
$('iframe').iFrameResize([{ options }])
```
