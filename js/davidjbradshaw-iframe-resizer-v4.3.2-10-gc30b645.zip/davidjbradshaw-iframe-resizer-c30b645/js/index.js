var iframeResize = require('./iframeResizer')

exports.iframeResize = iframeResize
exports.iframeResizer = iframeResize // Backwards compatibility
exports.iframeResizerContentWindow = require('./iframeResizer.contentWindow')
